package com.pluralsight;

public class Cat {
}
